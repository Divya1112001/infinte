﻿namespace Infinite.Casestudy2
{
    public class LocalDate
    {
    }
}